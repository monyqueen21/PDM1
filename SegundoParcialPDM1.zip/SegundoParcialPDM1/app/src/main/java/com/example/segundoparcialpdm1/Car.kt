package com.example.segundoparcialpdm1

data class Car (val brand:String, val model:String, val year:String, val url: String, val latitude: Double, val longitude: Double)