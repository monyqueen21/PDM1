package com.example.segundoparcialpdm1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.maps.GoogleMap
import com.squareup.picasso.Picasso

class MenuActivity : AppCompatActivity() {

    private lateinit var welcomeText: TextView

    private var currentIndex = 0
    private var carBank= mutableListOf<Car>(
        Car("Tesla", "Model X", "2021", "https://www.tesla.com/assets/img/mx_fb_s.jpg", 28.6491, -106.0607),
        Car("Audi", "Etron", "2020", "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/audi-a6-e-tron-1619193007.jpg?crop=1.00xw:0.674xh;0,0.195xh&resize=1200:*", 28.7095, -106.1395),
        Car("BMW", "i4", "2021", "https://i.blogs.es/29286e/p90384988_highres_bmw-concept-i4-02-20/1366_2000.jpg", 28.6434, -106.0514),
        Car("Mercedes", "eqp", "2020", "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/21c0254-013-1630860884.jpg", 28.6119, -106.1163),
        Car("KIA", "ev6", "2021", "https://www.hibridosyelectricos.com/media/hibridos/images/2021/03/30/2021033016222044764.jpg", 28.6304, -106.1236)
    )

    private lateinit var brandLabel: TextView
    private lateinit var modelLabel: TextView
    private lateinit var yearLabel: TextView
    private lateinit var carImage: ImageView

    private lateinit var nextButton: Button
    private lateinit var logOutButton: Button

    private lateinit var mapButton: Button
    private lateinit var qrScannerButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        welcomeText = findViewById(R.id.welcome_text)
        val username: String? = intent.getStringExtra("username")

        var brandExtra: String? = intent.getStringExtra("brand")
        val modelExtra: String? = intent.getStringExtra("model")
        val yearExtra:String? = intent.getStringExtra("year")
        val urlExtra: String? = intent.getStringExtra("url")
        val latitudeExtra:String? = intent.getStringExtra("latitude")
        val longitudeExtra:String? = intent.getStringExtra("longitude")

        if (username != null){
            val newWelcomeText = "Bienvenido: ${username.toString()}"
            welcomeText.setText(newWelcomeText)
        }

        if (brandExtra != null){
            carBank.add(Car(brandExtra.toString(), modelExtra.toString(), yearExtra.toString(), urlExtra.toString(), latitudeExtra.toString().toDouble(), longitudeExtra.toString().toDouble()))
        }

        carImage = findViewById(R.id.car_image)
        brandLabel = findViewById(R.id.brand_label)
        modelLabel = findViewById(R.id.model_label)
        yearLabel = findViewById(R.id.year_label)

        Picasso.get().setLoggingEnabled(true)
        Picasso.get().load(carBank[currentIndex].url).centerCrop().resize(300,150).into(carImage)

        nextButton = findViewById(R.id.next_button)
        nextButton.setOnClickListener{
            currentIndex = (currentIndex + 1) % carBank.size
            updateCar()
        }

        logOutButton = findViewById(R.id.log_out_btn)
        logOutButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply{
            }
            startActivity(intent)
        }

        mapButton = findViewById(R.id.view_map_btn)
        mapButton.setOnClickListener {
            val intent = Intent(this, GoogleMapsActivity::class.java)
            var latitude = carBank[currentIndex].latitude
            var longitude = carBank[currentIndex].longitude
            intent.putExtra("latitude", latitude)
            intent.putExtra("longitude", longitude)
            startActivity(intent)
        }

        qrScannerButton = findViewById(R.id.add_car_btn)
        qrScannerButton.setOnClickListener{

        }

     }

    private fun updateCar() {
        var image = carBank[currentIndex].url
        Picasso.get().load(image).centerCrop().resize(300,150).into(carImage)

        var brand = carBank[currentIndex].brand
        brandLabel.setText(brand)

        var model = carBank[currentIndex].model
        modelLabel.setText(model)

        var year = carBank[currentIndex].year
        yearLabel.setText(year)


    }
}