package com.example.segundoparcialpdm1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.airbnb.lottie.LottieAnimationView

class MainActivity : AppCompatActivity() {

    private lateinit var wrongIcon: LottieAnimationView
    private lateinit var passwordInput: TextView
    private lateinit var usernameInput: TextView
    private lateinit var loginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        passwordInput = findViewById(R.id.password_input)
        usernameInput = findViewById(R.id.username_input)
        loginButton = findViewById(R.id.log_in_btn)
        wrongIcon = findViewById(R.id.error_icon_anim)

        wrongIcon.visibility = View.INVISIBLE

        loginButton.setOnClickListener{
            var password = passwordInput.text.toString()
            var username = usernameInput.text.toString()

            verifyUser(password, username)
        }

    }

    private fun verifyUser(password: String, username: String) {
        if (username == "SegundoParcial" && password == "ULSA2021"){
            val intent = Intent(this, MenuActivity::class.java)
            intent.putExtra("username", username)
            startActivity(intent)
        } else {
            wrongIcon.visibility = View.VISIBLE
            Toast.makeText(applicationContext,"Contraseña incorrecta", Toast.LENGTH_LONG).show()
        }
    }
}